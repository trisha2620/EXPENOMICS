EXPENOMICS — Project Cost Estimation & Financial Management
===========================================================

EXPENOMICS is a clean, client-side application built to help freelancers, 
consultants, agency owners, and project leads handle quoting, tax rules, and 
client reporting easily.

I designed this project to solve a common headache: preparing project budgets, 
organising team and resource assignments, handling local tax rules (like GST or 
VAT), and making executive-ready PDF documents. It does all this without needing 
heavy software suites, complex backend setups, or slow third-party services.


KEY HIGHLIGHTS
--------------

1. 100% Client-Side & Zero Backend Overhead: Runs entirely in your modern web 
   browser using sessionStorage and a fallback temporary memory state. You do 
   not need any server setups, external databases, or data transmission.
2. Dynamic 3D User Interface: Designed with pure CSS 3D rotating shapes and 
   tactile, pseudo-3D buttons that feel like real keys. Features a one-click 
   Light/Dark mode toggle and live cost breakdown widgets.
3. Global Tax & Currency Matrix: Built-in country directory with automatic ISO 
   currency mapping. Includes a smart India GST Engine for automatic CGST, 
   SGST, and IGST division, plus ready-to-use presets for the US and Canada.
4. Resource & Team Cost Modeling: Dedicated setup for Project Manager costs 
   and a dynamic team registry to track roles, employment terms, seniority 
   levels, and quick entry validation.
5. Structured Expense Tracking: Clear itemised tracking across Development, 
   Marketing, and Operational categories, along with a tracking view to separate 
   paid and outstanding liabilities.
6. Modular PDF Generation Engine: Quickly creates 4 distinct report types 
   (Detailed, Summary, Client Quotation, Internal Audit) plus a comprehensive 
   Full Project Report using your browser's native "Save as PDF" feature.
7. Company Directory: Saves, loads, updates, and deletes multiple company or 
   client workspaces right within the active tab session.


TECHNOLOGY STACK
----------------

The application is engineered with an intentional zero-dependency philosophy to 
ensure lightning-fast startup times, complete portability, and offline-ready 
execution:

[ Structure ]             Semantic HTML5, accessible form attributes, tabbed 
                          view panels.
[ Styling ]               Vanilla CSS3, CSS Custom Properties (Theming), CSS Grid, 
                          Flexbox, 3D CSS Transforms (preserve-3d).
[ Logic & Computation ]   Modern JavaScript (ES6+), Event Delegation 
                          Architecture, State Serialization.
[ Security & Crypto ]     Web Crypto API (crypto.subtle SHA-256 password digest).
[ Internationalization ]  Native Intl.NumberFormat for currency formatting, 
                          Unicode regex properties (\p{L}, \p{M}).


ARCHITECTURE & CODE STRUCTURE
-----------------------------

The entire codebase is structured cleanly within a single self-contained document 
(index.html) across three distinct segments:

1. Part 1: Styles (<style>)
   Centralized theme tokens, surface elevations, and print stylesheet rules 
   (@media print, @page) optimizing tables for standard paper margins.

2. Part 2: Structure (<body>)
   Auth Screen featuring a pure CSS rotating cube showcase, unified login/reg 
   modules, Workspace Layout panels, and an isolated Print Container.

3. Part 3: Business Logic (<script>)
   Helper utilities, regex validators, session storage adapters, regional tax 
   datasets, and a single-listener event delegation system.


VALIDATION & INPUT RULES
------------------------

EXPENOMICS enforces rigorous client-side input validation to safeguard 
calculation accuracy:

1. Password Policy: Exactly 8 characters (maxlength="8") containing at least one 
   letter, one numeric digit, and one symbol (no spaces) with a real-time length 
   indicator.
2. Input Sanitization Filters: Real-time stripping filters for "letters" (retains 
   accented characters), "digits" (for telephone rows), and "decimal" (up to 2 
   decimal financial places).
3. Mandatory Field Guards: Crucial client and project headers are strictly validated 
   before financial reports or PDF exports can be triggered.


HOW TO RUN
----------

Because EXPENOMICS requires no build tools, compilers, or server runtimes, 
deployment is instant:

Option 1: Direct File Launch
1. Download or clone this repository:
   git clone https://github.com
2. Open index.html in any modern web browser.

Option 2: Local Static Server (Optional)
Run one of the following commands in your project directory:
   Python 3: python -m http.server 8000
   Node.js:  npx serve .
Then navigate to http://localhost:8000 in your browser.


CORE OPERATIONAL WORKFLOW
-------------------------

  [Create Account / Demo Sign-in]
                │
                ▼
  [Client & Project Setup] ────► Select country & currency (auto-tax presets)
                │
                ▼
  [Team & Resource Setup]  ────► Allocate PM and itemize team roles/rates
                │
                ▼
  [Expense Tracking]       ────► Log development, marketing, and incidental costs
                │
                ▼
  [Financial Calculation]  ────► Set profit margins, discounts, and tax splits
                │
                ▼
  [Review & Export]        ────► Preview customized report and "Save as PDF"


SECURITY & SESSION NOTICE
-------------------------

1. Demo Authentication: The authentication system demonstrates client-side 
   cryptographic hashing via crypto.subtle (SHA-256) intended strictly for local 
   workspace sandboxing and preview tools.
2. Session Lifespan: Project data lives inside window.sessionStorage; closing the 
   browser tab automatically flushes all transient records from memory.


LEGAL & COMPLIANCE DISCLAIMER
-----------------------------

EXPENOMICS is designed as a project financial forecasting and estimation tool. 
Tax legislation, statutory rates, withholding exemptions, and local surcharges 
vary widely by jurisdiction, trade classification, and corporate registration 
status. Always consult a licensed certified public accountant (CPA) or the 
relevant national tax authority before executing legal contracts or issuing 
binding tax invoices.


AUTHOR & LICENSE
----------------

Developed with precision for modern software estimation and client pricing workflows. 
Released under the MIT License (LICENSE).

